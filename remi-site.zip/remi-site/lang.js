(function(){
var d=document.documentElement,sel=document.getElementById('lang');
var T={
tr:{support:'Destek',privacy:'Gizlilik',rights:'Tüm hakları saklıdır.'},
en:{support:'Support',privacy:'Privacy',rights:'All rights reserved.'},
de:{support:'Support',privacy:'Datenschutz',rights:'Alle Rechte vorbehalten.'},
fr:{support:'Assistance',privacy:'Confidentialité',rights:'Tous droits réservés.'},
es:{support:'Soporte',privacy:'Privacidad',rights:'Todos los derechos reservados.'}};
function set(l){d.lang=l;sel.value=l;var t=T[l];
document.querySelectorAll('[data-i]').forEach(function(e){e.textContent=t[e.getAttribute('data-i')]})}
var n=(navigator.language||'en').slice(0,2).toLowerCase();
set(Object.prototype.hasOwnProperty.call(T,n)?n:'en');
sel.addEventListener('change',function(){set(sel.value)});
})();
